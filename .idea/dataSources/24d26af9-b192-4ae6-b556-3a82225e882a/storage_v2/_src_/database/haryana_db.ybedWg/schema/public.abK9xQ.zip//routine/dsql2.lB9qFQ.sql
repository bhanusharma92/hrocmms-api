create function dsql2(i_text text) returns integer
LANGUAGE plpgsql
AS $$
Declare
  v_val int;
BEGIN
  execute i_text into v_val;
  return v_val;
END;
$$;
